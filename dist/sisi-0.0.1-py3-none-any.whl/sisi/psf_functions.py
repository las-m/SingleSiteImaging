# -*- coding: utf-8 -*-
"""
Created on Sun Dec 22 22:18:35 2024

@author: scott
"""

def gaussian_2d(xy, center_x, center_y, waist_x, waist_y, z0):
    return 0