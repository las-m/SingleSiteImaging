# -*- coding: utf-8 -*-
"""
Created on Fri Dec 20 08:45:47 2024

@author: scott
"""

